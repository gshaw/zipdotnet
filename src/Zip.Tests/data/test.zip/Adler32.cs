/*
 * [NetZip license here]
 * 
 * [JOS license here]
 */

/*
 * This code is based on the zlib 1.1.2, a general purpose data compression library.
 *
 * zlib is distributed under the following conditions:
 *
 *  (C) 1995-1998 Jean-loup Gailly and Mark Adler
 *
 *  This software is provided 'as-is', without any express or implied
 *  warranty.  In no event will the authors be held liable for any damages
 *  arising from the use of this software.
 *
 *  Permission is granted to anyone to use this software for any purpose,
 *  including commercial applications, and to alter it and redistribute it
 *  freely, subject to the following restrictions:
 *
 *  1. The origin of this software must not be misrepresented; you must not
 *     claim that you wrote the original software. If you use this software
 *     in a product, an acknowledgment in the product documentation would be
 *     appreciated but is not required.
 *  2. Altered source versions must be plainly marked as such, and must not be
 *     misrepresented as being the original software.
 *  3. This notice may not be removed or altered from any source distribution.
 *
 */

/*
 * Implementation of the CRC32 class for JOS.
 *
 * Like the Adler32, this one could have been faster if Java had supported unsigned integers.
 *
 */

using System;

namespace Mono.Zip {

    public class Adler32 : IChecksum
    {
        private long adler = 1L;
        
        private const int BASE = 65521; // largest prime smaller than 65536
        private const int NMAX = 5552;  // NMAX is the largest n such that 255n(n+1)/2 + (n+1)(BASE-1) <= 2^32-1
        
        public void update (int b) 
        {
            b &= 0xff;
            long s1 = adler & 0xffff;
            long s2 = (adler >> 16) & 0xffff;
            s1 += b;
            s2 += s1;
            s1 %= BASE;
            s2 %= BASE;
            adler = (s2 << 16) | s1;
        }
        
        public void update (byte[] b, int off, int len) 
        {
            if (b == null) 
            {
                throw new ArgumentNullException("b");
            }
            if( (off < 0) || (len < 0) || (off + len > b.Length) ) 
            {
                throw new ArgumentOutOfRangeException();
            }
            
            long s1 = adler & 0xffff;
            long s2 = (adler >> 16) & 0xffff;
            int k;
            
            while(len > 0) 
            {
                k = (len < NMAX) ? (len) : (NMAX);
                len -= k;
                while (k >= 16) 
                {
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    s2 += s1 += b[off] & 0xff; off++;
                    k -= 16;
                }
                while (k != 0) 
                {
                    s2 += s1 += b[off] & 0xff; off++;
                    k--;
                }
                s1 %= BASE;
                s2 %= BASE;
            }
            
            adler = (s2 << 16) | s1;
        }
        
        public void update (byte[] b) 
        {
            update (b, 0, b.Length);
        }
        
        public void reset() 
        {
            adler = 1L;
        }
        
        public uint getValue()
        {
            return (uint) adler;
        }
    }

}