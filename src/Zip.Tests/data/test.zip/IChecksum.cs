/*
 * [NetZip license here]
 * 
 * [JOS license here]
 */

namespace Mono.Zip {

    public interface IChecksum
    {
        void update(int b);
        
        void update(byte[] b, int off, int len);
        
        uint getValue();

        void reset();
    }

}
