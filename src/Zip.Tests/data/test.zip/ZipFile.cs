/*
 * [NetZip license here]
 */

using System;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;

namespace Mono.Zip {

    public sealed class ZLib {

        [DllImport("zlib.dll")]
        unsafe static extern int compress(byte[] destination, uint* destinationLength, byte[] source, uint sourceLength);

        [DllImport("zlib.dll")]
        static extern uint adler32(uint adler, byte[] buffer, uint length);

        [DllImport("zlib.dll")]
        unsafe static extern uint crc32(uint crc, byte* buffer, uint length);
        
        [DllImport("zlib.dll")]
        unsafe static extern sbyte* zlibVersion();

        public static string Version {
            get {
                unsafe {
                    return new String(zlibVersion());
                }
            }
        }

        private ZLib() {
        }
    }

    public class TestApplication {
        public static void Main() {
            Console.WriteLine("Testing ZLib version {0}", ZLib.Version);

            ZipFileInfo zip = new ZipFileInfo("test.zip");

        }
    }

    public enum CompressionMethod {
        Stored,
        Deflated
    }

    public class ZipEntry {

        bool _isDirectory = false;
        string _name;
        string _comment;
        long _length = 0;
        long _compressedLength = 0;
        long _crc32 = -1;
        CompressionMethod _method = CompressionMethod.Deflated;
        DateTime _time = DateTime.Now;
        
        public ZipEntry(string name) {
            _name = name;
        }

        public string Name {
            get { return _name; }
            set { _name = value; }
        }

        public string Comment {
            get { return _comment; }
            set { _comment = value; }
        }

        bool IsDirectory {
            get { return _isDirectory; }
        }

        // uncompressed length in bytes
        long Length {
            get { return _length; }
            set { _length = value; }
        }

        long CompressedLength {
            get { return _compressedLength; }
            set { _compressedLength = value; }
        }

        public DateTime Time {
            get { return _time; }
            set { _time = value; }
        }

        public long Crc {
            get { return _crc32; }
            set { _crc32 = value; }
        }

        public CompressionMethod Method {
            get { return _method; }
            set { _method = value; }
        }

        // TODO: public override string ToString()
    }

    public class ZipEntryCollection : ArrayList {
    }

    public class ZipFileInfo {

        string _fileName;
        ZipEntryCollection _entries = new ZipEntryCollection();

        public ZipFileInfo(string fileName) {
            _fileName = fileName;
        }

        public string Name {
            get { return _fileName; }
        }

        public ZipEntryCollection Entires {
            get { return _entries; }
        }
        
        public FileStream Open(ZipEntry entry) {
            return null;
        }

        public void Close() {
        }
    }
/*
    public sealed class ZipFile {
        static public ZipEntryCollection Entries(string fileName) {
            ZipFileInfo info = new ZipFileInfo(fileName);
            return info.Entries;
        }

        private ZipFile() {
        }
    }
*/
}