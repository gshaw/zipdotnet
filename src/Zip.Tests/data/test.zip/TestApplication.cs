/*
 * [NetZip license here]
 */

using System;

namespace Mono.Zip {

}